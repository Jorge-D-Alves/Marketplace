import { combineReducers } from 'redux';

import shop from '../modules/shop/reducer';

export default combineReducers({
  shop,
});
